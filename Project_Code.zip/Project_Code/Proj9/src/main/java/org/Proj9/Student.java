package org.Proj9;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/stu")
public class Student {
	
	
	@GET
	@Path("/Add/{rollno}/{name}/{age}/{city}")
	
	public String getdetails(@PathParam("rollno") int roll,@PathParam("name") String nm,@PathParam("age") int ag,@PathParam("city") String ct) {
		
	     Connection cn;
	     Statement smt;
	     ResultSet rs;
	     
	   
	  

	     try 
	     {
	    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
	    	 //Register Driver
	    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
	    	
			smt=cn.createStatement();
			smt.executeUpdate("insert into Student values("+roll+",'"+nm+"',"+ag+",'"+ct+"')");
			cn.commit(); 
			smt.close();
			 
	    	
	     }
	     catch(Exception e)
	     {
	    	 System.out.println(e);
	     }
	     
	   
	     return "DATA SAVED SUCCESSFULLY";
	    
	}
	
	
	@GET
	@Path("/delete/{rollno}")
	
	public String getdetail(@PathParam("rollno") int roll) {
		
	     Connection cn;
	     Statement smt;
	     ResultSet rs;
	     
	   
	  

	     try 
	     {
	    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
	    	 //Register Driver
	    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
	    	
			smt=cn.createStatement();
			smt.executeUpdate("delete from Student where roll='"+roll+"'");
			cn.commit(); 
			smt.close();
			 
	    	
	     }
	     catch(Exception e)
	     {
	    	 System.out.println(e);
	     }
	     
	   
	     return "DATA DELETED SUCCESSFULLY";
	    
	}
	
	
	
	@GET
	@Path("/update/{rollno}")
	
	public String get(@PathParam("rollno") int roll) {
		
	     Connection cn;
	     Statement smt;
	     ResultSet rs;
	     
	   
	  

	     try 
	     {
	    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
	    	 //Register Driver
	    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
	    	
			smt=cn.createStatement();
			smt.executeUpdate("UPDATE Student SET city = 'Pune' WHERE roll= "+roll);
			cn.commit(); 
			smt.close();
			 
	    	
	     }
	     catch(Exception e)
	     {
	    	 System.out.println(e);
	     }
	     
	   
	     return "DATA UPDATED SUCCESSFULLY";
	    
	}
	
	
	@GET
	@Path("/show")
	
	public String ge() {
		
	     Connection cn;
	     Statement smt;
	    
	    
	   
	  

	     try 
	     {
	    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
	    	 //Register Driver
	    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
	    	
	    	 
			smt=cn.createStatement();
			 ResultSet rs=smt.executeQuery("select * from Student");
			
			
			while (rs.next()) {
				
				String r=rs.getString(1);
				String n=rs.getString(2);
				String a=rs.getString(3);
				String c=rs.getString(4);
				
				System.out.println("Rollno :"+r+" "+"Name :"+n+" "+"Age"+a+" "+"City :"+c);
			   }
			
			
			
			
		
			cn.commit(); 
			smt.close();
			 
	    	
	     }
	     catch(Exception e)
	     {
	    	 System.out.println(e);
	     }
	     
	   
	     return "DATA SHOWN SUCCESSFULLY";
	    
	}
	
	
	
	
	
	}
	
	



