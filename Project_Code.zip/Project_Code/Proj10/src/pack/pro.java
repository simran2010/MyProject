package pack;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
class a
{
	String s1,ele1,ele2;
	String empcode;
	String name;
	String address;
	String salary;
	ArrayList<String> list=new ArrayList<String>();
	Scanner s;
	


public void listing()
{
	s=	new Scanner(System.in);
	System.out.println("ENTER EMPLOYEE CODE:");
	empcode =s.nextLine();
	s.nextLine();
	System.out.println("ENTER EMPLOYEE NAME :");
	name = s.nextLine();
	s.nextLine();
	System.out.println("ENTER EMPLOYEE SALARY :");
    salary =s.nextLine();
	System.out.println("ENTER EMPLOYEE ADDRESS :");
    address =s.next();



list.add(name);
list.add(empcode);
list.add(salary);
list.add(address);

Iterator itr=list.iterator();
while(itr.hasNext()){  
System.out.println(itr.next());
}
}

 public void delete()
 {
	 s=	new Scanner(System.in);
System.out.println("ENTER NAME/CODE/ADDRESS/SALARY TO DELETE");
 s1=s.nextLine();

if(s1.equals("name"))
{
	list.remove(name);
	System.out.println("DELETED SUCCESSFULLY !!");
	
}


else if(s1.equals("salary"))
{
	list.remove(salary);
	System.out.println("LIST AFTER DELETION.......");
	
}


else if(s1.equals("empcode"))
{
	list.remove(empcode);
	System.out.println("LIST AFTER DELETION......");
	
}


else if(s1.equals("address"))
{
	list.remove(address);
	System.out.println(" DELETED SUCCESSFULLY !!");
	
	
}
else
{
	System.out.println("OOPS ....THERE IS NO ANY FIELD!!!!!!");
}

Iterator itr=list.iterator();
System.out.println("AFTER DELETION.....");
while(itr.hasNext()){  
System.out.println(itr.next());
}


}

 public void update()
 {
	 s=	new Scanner(System.in);
System.out.println("ENTER NAME/CODE/ADDRESS/SALARY TO UPDATE");
 ele1=s.nextLine();
 System.out.println("ENTER VALUE");
 ele2=s.nextLine();
if(ele1.equals("name"))
{
	list.set(0,ele2 );
	System.out.println("UPDATED SUCCESSFULLY !!");
	
}


else if(ele1.equals("empcode"))
{
	list.set(1, ele2);
	System.out.println("UPDATED SUCCESSFULLY !!");
	
}


else if(ele1.equals("salary"))
{
	list.set(2, ele2);
	System.out.println("UPDATED SUCCESSFULLY !!");
	
}


else if(ele1.equals("address"))
{
	list.set(3, ele2);
	System.out.println("UPDATED SUCCESSFULLY !!");
	
	
}
else
{
	System.out.println("OOPS ....THERE IS NO ANY FIELD!!!!!!");
}

Iterator itr=list.iterator();
System.out.println("LIST AFTER UPDATION......");
while(itr.hasNext()){  
System.out.println(itr.next());
}



}



}


public class pro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
a a1 =new a();
a1.listing();
a1.update();
a1.delete();
	}

}



