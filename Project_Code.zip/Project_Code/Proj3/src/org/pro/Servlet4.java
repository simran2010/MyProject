package org.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet4
 */
@WebServlet("/Servlet4")
public class Servlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		
		String id=request.getParameter("rn");

		String name=request.getParameter("nm");
		
		
		
		
	     Connection cn;
	     Statement smt;
	    
	     
	   
	  

	     try 
	     {
	    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
	    	 //Register Driver
	    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
	    	
			smt=cn.createStatement();
			ResultSet rs=smt.executeQuery("update Diary SET Contact='"+name+"' where ID="+id);
			
			
			
			cn.commit(); 
			smt.close();
			 
	    	
	     }
	     catch(Exception e)
	     {
	    	 System.out.println(e);
	     }
	     
	   
	  out.print("Data Updated Successfully");
	    
	}
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
