package org.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		

		String name=request.getParameter("nm");
		
		String Id =request.getParameter("id");
		
		
	     Connection cn;
	     Statement smt;
	    
	     
	   
	  

	     try 
	     {
	    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
	    	 //Register Driver
	    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
	    	
			smt=cn.createStatement();
			ResultSet rs=smt.executeQuery("select * from  Diary where ID="+Id);
			
			
			while(rs.next()) {
			
		    out.print("ID :"+rs.getString(1) +" "+"Name :" +rs.getString(2) +" "+"Contact :"+rs.getString(3));
			}
			
			cn.commit(); 
			smt.close();
			 
	    	
	     }
	     catch(Exception e)
	     {
	    	 System.out.println(e);
	     }
	     
	   
	  
	    
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
