#include<iostream>
using namespace std;
 class STACK
{
    private:
        int num[4];
        int top;
    public:
        STACK();    
        int push(int);
        int pop();
        int isEmpty();
        int isFull();
        void displayItems();
};
STACK::STACK(){
    top=-1;
}
 
int STACK::isEmpty(){
    if(top==-1)
        return 1;
    else
        return 0;   
}
 
int STACK::isFull(){
    if(top==(3))
        return 1;
    else
        return 0;
}
 
int STACK::push(int n){
    if(isFull()){
        return 0;
    }
    ++top;
    num[top]=n;
    return n;
}
 
int STACK::pop(){
  
    int temp;
    if(isEmpty())
        return 0;
    temp=num[top];
    --top;
    return temp;
     
}
 
void STACK::displayItems(){
    int i; 
    cout<<"STACK is: ";
    for(i=(top); i>=0; i--)
        cout<<num[i]<<" ";
    cout<<endl;
}
 
int main(){
    STACK stk;
    int a[4];
    int choice, n,temp,l;
    
    for(int i=0;i<5;i++)
    {
     cout<<"Enter item to insert: ";
                cin>>n;
                temp=stk.push(n);
               
                if(temp==0)
                    cout<<"STACK is FULL."<<endl;
                else
                    cout<<temp<<" inserted."<<endl;
                    	
	}
	cout<<" ";
		                    
				                    

                    
    temp=stk.pop();
                if(temp==0)
                {
				
                    cout<<"STACK IS EMPTY."<<endl;
                }
                else
                {
				                    cout<<temp<<" is removed (popped)."<<endl;
                    
                    
				                   


				                    	
									}
								
				 	cout<<" ";
                 			                    

	
	stk.displayItems();
            


}


